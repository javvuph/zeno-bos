// App-wide constants
