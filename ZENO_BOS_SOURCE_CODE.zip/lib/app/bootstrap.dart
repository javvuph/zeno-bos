// App initialization logic
