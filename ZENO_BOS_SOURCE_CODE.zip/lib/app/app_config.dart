// App configuration (environment, etc.)
