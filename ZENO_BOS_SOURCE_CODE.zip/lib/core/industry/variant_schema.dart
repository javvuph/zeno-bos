// Variant schema definition
