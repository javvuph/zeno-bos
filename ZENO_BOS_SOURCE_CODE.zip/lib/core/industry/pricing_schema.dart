// Pricing schema definition
