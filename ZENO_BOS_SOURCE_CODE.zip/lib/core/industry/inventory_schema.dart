// Inventory schema definition
