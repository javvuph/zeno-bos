// Category schema definition
