// Attribute schema definition
